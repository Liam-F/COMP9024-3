package net.datastructures;
/**
 * An interface for a vertex of a graph.
 * @author Roberto Tamassia
 */
public interface Vertex<E> extends DecorablePosition<E> { }
